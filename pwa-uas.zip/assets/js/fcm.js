if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('firebase-messaging-sw.js')
        .then(function(registration) {
            console.log('Service Worker fcm berhasil didaftarkan:', registration);
        })};

         if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js')
                .then(function(registration) {
                    console.log('Service Worker sw berhasil didaftarkan:', registration);
                })};

var firebaseConfig = {
apiKey: "AIzaSyAwbPYg-1smNYn1SNGg4lLwGIImAPZ-r_Y",
authDomain: "tugas-fcm-b3866.firebaseapp.com",
projectId: "tugas-fcm-b3866",
storageBucket: "tugas-fcm-b3866.appspot.com",
messagingSenderId: "813557277537",
appId: "1:813557277537:web:75092a29683f65afb99b20",
measurementId: "G-WQB5YL9NYF"
};
firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

function IntitalizeFireBaseMessaging() {
messaging
  .requestPermission()
  .then(function () {
      console.log("Notification Permission");
      return messaging.getToken();
  })
  .then(function (token) {
      console.log("Token : " + token);
      document.getElementById("token").innerHTML = token;
  })
  .catch(function (reason) {
      console.log(reason);
  });
}

messaging.onMessage(function (payload) {
console.log(payload);
const notificationOption = {
  body: payload.notification.body,
  icon: payload.notification.icon
};

if (Notification.permission === "granted") {
  var notification = new Notification(payload.notification.title, notificationOption);

  notification.onclick = function (ev) {
      ev.preventDefault();
      window.open(payload.notification.click_action, '_blank');
      notification.close();
  };
}
});

messaging.onTokenRefresh(function () {
messaging.getToken()
  .then(function (newtoken) {
      console.log("New Token : " + newtoken);
  })
  .catch(function (reason) {
      console.log(reason);
  }); 
});

IntitalizeFireBaseMessaging();


// fungsi send ke server fcm
function sendNotification() {
var url = "https://fcm.googleapis.com/fcm/send";

var fields = {
  to: document.getElementById('token').innerHTML,
  notification: {
      body: document.getElementById('pesan').value,
      title: document.getElementById('title').value,
      icon: document.getElementById('icon').value,
      click_action: "http://127.0.0.1:5500/"
  }
};

var headers = {
  'Authorization': 'key=AAAAvWvK42E:APA91bG6gzvGk_k3cWQTeVhGkxwKCR8fQRAWLQ6qQVXPo3dr_clu6fQqy19fSuYFKjdncFHeEbx2IeuVDjHwCMqOUQ3bHtN9d40nocTTYR_z-UO9ds7VF8H699k30PSgZQe5KMxowRAz',
  'Content-Type': 'application/json'
};

var xhttp = new XMLHttpRequest();
xhttp.onreadystatechange = function () {
  if (this.readyState === 4 && this.status === 200) {
      console.log(this.responseText);
  }
};

xhttp.open("POST", url, true);
xhttp.setRequestHeader("Content-type", "application/json");
for (var header in headers) {
  xhttp.setRequestHeader(header, headers[header]);
}

xhttp.send(JSON.stringify(fields));
}

// function showNotification(message) {
//         if ('Notification' in window) {
//             Notification.requestPermission().then(function (permission) {
//                 if (permission === 'granted') {
//                     const notification = new Notification('Pemberitahuan', {
//                         body: message,
//                     });
//                 }
//             });
//         }
//     }