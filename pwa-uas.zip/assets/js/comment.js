document.addEventListener('DOMContentLoaded', function () {
    // Membuat atau membuka database IndexedDB
    const dbName = "CommentsDB";
    const request = indexedDB.open(dbName, 1);
    let db;

    // Menangani peristiwa pembuatan atau pembukaan database
    request.onupgradeneeded = function (event) {
        db = event.target.result;
        const objectStore = db.createObjectStore("Comments", { keyPath: "id", autoIncrement: true });
        objectStore.createIndex("firstName", "firstName", { unique: false });
        objectStore.createIndex("lastName", "lastName", { unique: false });
        objectStore.createIndex("email", "email", { unique: false });
        objectStore.createIndex("message", "message", { unique: false });
    };

    request.onsuccess = function (event) {
        db = event.target.result;
        showComments();
    };

    request.onerror = function (event) {
        console.error("Error opening database:", event.target.error);
    };

    // Fungsi untuk menambahkan data ke dalam database
    function addComment(comment) {
        const transaction = db.transaction(["Comments"], "readwrite");
        const objectStore = transaction.objectStore("Comments");
        const request = objectStore.add(comment);

        request.onsuccess = function () {
            console.log("Comment added successfully!");
            showComments();
        };

        request.onerror = function (event) {
            console.error("Error adding comment:", event.target.error);
        };
    }

    // Fungsi untuk menampilkan komentar
    function showComments() {
        const commentsContainer = document.getElementById("comments");
        commentsContainer.innerHTML = "";

        const objectStore = db.transaction("Comments").objectStore("Comments");
        objectStore.openCursor().onsuccess = function (event) {
            const cursor = event.target.result;
            if (cursor) {
                const commentDiv = document.createElement("div");
                commentDiv.innerHTML = `<p><strong>${cursor.value.firstName} ${cursor.value.lastName}</strong>: ${cursor.value.message}</p>`;
                commentsContainer.appendChild(commentDiv);
                cursor.continue();
            }
        };
    }

    // Menangani pengiriman formulir
    const contactForm = document.getElementById("contactForm");
    contactForm.addEventListener("submit", function (event) {
        // Mengambil nilai input
        const firstName = document.getElementById("name").value;
        const lastName = document.getElementById("L_name").value;
        const email = document.getElementById("email").value;
        const message = document.getElementById("message").value;

        // Validasi manual
        if (!firstName || !lastName || !email || !message) {
            alert("Mohon isi semua kolom formulir!");
            event.preventDefault(); // Mencegah pengiriman formulir jika tidak valid
            return;
        }

        // Buat objek komentar
        const comment = {
            firstName: firstName,
            lastName: lastName,
            email: email,
            message: message,
        };

        // Tambahkan komentar ke IndexedDB
        addComment(comment);

        // Reset formulir
        contactForm.reset();
    });
});
